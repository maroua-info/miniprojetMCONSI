<?php

include("../includes/header.php");

include("../includes/navbar.php");

include("../includes/db.php");

$users_query =
mysqli_query(
$conn,
"SELECT COUNT(*) AS total
 FROM users"
);

$users =
mysqli_fetch_assoc(
$users_query
);

$contests_query =
mysqli_query(
$conn,
"SELECT COUNT(*) AS total
 FROM contests"
);

$contests =
mysqli_fetch_assoc(
$contests_query
);

$scores_query =
mysqli_query(
$conn,
"SELECT COUNT(*) AS total
 FROM scores"
);

$scores =
mysqli_fetch_assoc(
$scores_query
);

$organizers_query =
mysqli_query(
$conn,
"SELECT COUNT(*) AS total
 FROM users
 WHERE role='organisateur'"
);

$organizers =
mysqli_fetch_assoc(
$organizers_query
);

if(!isset($_SESSION['user'])
   || $_SESSION['role'] != "admin"){

    header("Location: ../login.php");

    exit();

}

?>

<h1 class="mb-4">

Administration Dashboard

</h1>

<div class="alert alert-success">

Bienvenue Admin :
<?php echo $_SESSION['user']; ?>

</div>

<div class="row mt-4">

<div class="col-md-4">

<div class="card shadow p-4 text-center">

<h2 class="text-primary">

<?php
echo $users['total'];
?>

</h2>

<p>Membres</p>

</div>

</div>

<div class="col-md-4">

<div class="card shadow p-4 text-center">

<h2 class="text-success">

<?php
echo $contests['total'];
?>

</h2>

<p>Concours</p>

</div>

</div>

<div class="col-md-4">

<div class="card shadow p-4 text-center">

<h2 class="text-danger">

<?php
echo $scores['total'];
?>

</h2>

<p>Résultats</p>

</div>

</div>

</div>

<div class="card shadow p-4 mt-5">

<h3 class="mb-4">

Actions Rapides

</h3>

<div class="d-grid gap-2">

<a href="#"
   class="btn btn-primary">

Gestion Membres

</a>

<a href="../organizer/contests.php"
   class="btn btn-success">

Voir Concours

</a>

<a href="../organizer/add_contest.php"
   class="btn btn-info">

Ajouter Concours

</a>

</div>

</div>

<div class="card shadow p-4 mt-5">

<h3 class="mb-4">

Derniers Concours

</h3>

<table class="table table-bordered table-hover">

<thead class="table-dark">

<tr>

<th>ID</th>

<th>Titre</th>

<th>Date</th>

<th>Lieu</th>

</tr>

</thead>

<tbody>

<?php

$latest =
mysqli_query(
$conn,
"SELECT * FROM contests
 ORDER BY id DESC
 LIMIT 5"
);

while($row =
mysqli_fetch_assoc($latest)){

?>

<tr>

<td>

<?php echo $row['id']; ?>

</td>

<td>

<?php echo $row['titre']; ?>

</td>

<td>

<?php echo $row['date_concours']; ?>

</td>

<td>

<?php echo $row['lieu']; ?>

</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

<?php include("../includes/footer.php"); ?>