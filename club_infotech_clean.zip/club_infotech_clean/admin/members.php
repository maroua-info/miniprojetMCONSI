<?php

include("../includes/db.php");
include("../includes/header.php");
include("../includes/navbar.php");

if(!isset($_SESSION['user'])
   || $_SESSION['role'] != "admin"){

    header("Location: ../login.php");

    exit();

}

$sql = "SELECT * FROM users";

$result = mysqli_query($conn, $sql);

?>

<div class="container mt-5">

<h1 class="mb-4">

Gestion Membres

</h1>

<div class="card shadow p-4">

<table class="table table-bordered table-hover">

<thead class="table-dark">

<tr>

<th>ID</th>

<th>Nom</th>

<th>Email</th>

<th>Role</th>

</tr>

</thead>

<tbody>

<?php while($row = mysqli_fetch_assoc($result)){ ?>

<tr>

<td>

<?php echo $row['id']; ?>

</td>

<td>

<?php echo $row['username']; ?>

</td>

<td>

<?php echo $row['email']; ?>

</td>

<td>

<?php echo $row['role']; ?>

</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</div>

<?php include("../includes/footer.php"); ?>