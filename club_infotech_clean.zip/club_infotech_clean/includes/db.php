<?php

$conn = mysqli_connect(
    "localhost",
    "root",
    "",
    "club_infotech"
);

if(!$conn){

    die("Erreur connexion DB");

}

?>