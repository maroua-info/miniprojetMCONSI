<?php

if(session_status() === PHP_SESSION_NONE){

    session_start();

}

?>

<!DOCTYPE html>

<html lang="fr">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Club InfoTech</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
      rel="stylesheet">

<link rel="stylesheet"
      href="/club_infotech_clean/assets/css/style.css">

</head>

<body>

<div class="container mt-5">