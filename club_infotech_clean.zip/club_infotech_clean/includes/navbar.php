<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">

<div class="container-fluid">

<a class="navbar-brand"
   href="/club_infotech_clean/index.php">

    Club InfoTech

</a>

<div>

<a href="/club_infotech_clean/index.php"
   class="btn btn-outline-light btn-sm me-2">

Accueil

</a>

<a href="/club_infotech_clean/results.php"
   class="btn btn-warning btn-sm me-2">

Résultats

</a>

<?php if(!isset($_SESSION['user'])) { ?>

<a href="/club_infotech_clean/login.php"
   class="btn btn-outline-light btn-sm me-2">

Login

</a>

<a href="/club_infotech_clean/register.php"
   class="btn btn-success btn-sm me-2">

Register

</a>

<?php } ?>

<?php if(isset($_SESSION['user'])) { ?>
<?php if($_SESSION['role'] == "participant"){ ?>

<a href="participant/contests.php"
   class="btn btn-warning btn-sm">

Concours

</a>

<a href="participant/my_contests.php"
   class="btn btn-success btn-sm">

Mes Concours

</a>



<?php } ?>

<a href="/club_infotech_clean/profile.php"
   class="btn btn-info btn-sm me-2">

Profil




<?php if($_SESSION['role'] == "admin") { ?>

<a href="/club_infotech_clean/admin/dashboard.php"
   class="btn btn-secondary btn-sm me-2">

Admin

</a>

<?php } ?>

<?php if($_SESSION['role'] == "organisateur") { ?>

<a href="/club_infotech_clean/organizer/dashboard.php"
   class="btn btn-primary btn-sm me-2">

Dashboard

</a>

<?php } ?>

<a href="/club_infotech_clean/logout.php"
   class="btn btn-danger btn-sm">

Logout

</a>

<?php } ?>

</div>

</div>

</nav>