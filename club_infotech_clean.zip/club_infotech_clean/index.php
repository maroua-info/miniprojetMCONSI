<?php

include("includes/header.php");
include("includes/navbar.php");
include("includes/db.php");

$contests =
mysqli_query(
$conn,
"SELECT * FROM contests
ORDER BY date_concours DESC
LIMIT 3"
);

$scores =
mysqli_query(
$conn,
"SELECT * FROM scores
ORDER BY score DESC
LIMIT 5"
);

?>

<div class="bg-dark text-white p-5 rounded mb-5">

<h1 class="display-4">

Club InfoTech

</h1>

<p class="lead">

Plateforme de gestion des concours de programmation

</p>

<a href="register.php"
   class="btn btn-primary">

Rejoindre

</a>

</div>

<h2 class="mb-4">

🏆 Concours Disponibles

</h2>

<div class="row">

<?php while($contest = mysqli_fetch_assoc($contests)){ ?>

<div class="col-md-4 mb-3">

<div class="card shadow">

<div class="card-body">

<h5>

<?php echo $contest['titre']; ?>

</h5>

<p>

<?php echo $contest['description']; ?>

</p>

<p>

<b>Date :</b>
<?php echo $contest['date_concours']; ?>

</p>

<p>

<b>Lieu :</b>
<?php echo $contest['lieu']; ?>

</p>

</div>

</div>

</div>

<?php } ?>

</div>

<hr class="my-5">

<h2 class="mb-4">

🥇 Derniers Résultats

</h2>

<div class="card shadow">

<div class="card-body">

<table class="table">

<thead>

<tr>

<th>Participant</th>

<th>Contest</th>

<th>Score</th>

</tr>

</thead>

<tbody>

<?php while($row = mysqli_fetch_assoc($scores)){ ?>

<tr>

<td>

<?php echo $row['participant']; ?>

</td>

<td>

<?php echo $row['contest']; ?>

</td>

<td>

<?php echo $row['score']; ?>

</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</div>

<?php include("includes/footer.php"); ?>