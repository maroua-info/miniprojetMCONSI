<?php

include("includes/header.php");
include("includes/navbar.php");
include("includes/db.php");

if(isset($_POST['login'])){

    $email = $_POST['email'];

    $password = $_POST['password'];

    $sql =
    "SELECT * FROM users
     WHERE email='$email'";

    $result =
    mysqli_query($conn,$sql);

    if(mysqli_num_rows($result) > 0){

        $user =
        mysqli_fetch_assoc($result);

        if(
        password_verify(
        $password,
        $user['password']
        )){

            $_SESSION['user'] =
            $user['username'];

            $_SESSION['role'] =
            $user['role'];

            if($user['role'] == "admin"){

                header(
                "Location: admin/dashboard.php"
                );

            }

            else if(
            $user['role']
            == "organisateur"
            ){

                header(
                "Location: organizer/dashboard.php"
                );

            }

            else{

                header(
                "Location: profile.php"
                );

            }

            exit();

        }

        else{

            echo '

            <div class="alert alert-danger">

            Mot de passe incorrect

            </div>

            ';

        }

    }

    else{

        echo '

        <div class="alert alert-danger">

        Email introuvable

        </div>

        ';

    }

}

?>

<div class="card shadow p-5">

<h2 class="mb-4">

Connexion

</h2>

<form method="POST">

<div class="mb-3">

<label>Email</label>

<input type="email"
       name="email"
       class="form-control"
       required>

</div>

<div class="mb-3">

<label>Mot de passe</label>

<input type="password"
       name="password"
       class="form-control"
       required>

</div>

<button type="submit"
        name="login"
        class="btn btn-primary">

Login

</button>

</form>

</div>

<?php include("includes/footer.php"); ?>