<?php

include("../includes/db.php");
include("../includes/header.php");
include("../includes/navbar.php");

if(!isset($_SESSION['user'])
   || $_SESSION['role'] != "organisateur"){

    header("Location: ../login.php");

    exit();

}

$message = "";

if(isset($_POST['add_contest'])){

    $title = $_POST['title'];
    $description = $_POST['description'];
    $date = $_POST['date'];
    $place = $_POST['place'];

    $sql = "INSERT INTO contests
(titre, description, date_concours, lieu)
VALUES
('$title', '$description', '$date', '$place')";

    if(mysqli_query($conn, $sql)){

        $message = "Concours ajouté avec succès";

    } else {

        $message = "Erreur";

    }

}

?>

<div class="container mt-5">

<h1 class="mb-4">

Ajouter Concours

</h1>

<?php if($message != ""){ ?>

<div class="alert alert-success">

<?php echo $message; ?>

</div>

<?php } ?>

<div class="card shadow p-4">

<form method="POST">

<div class="mb-3">

<label class="form-label">

Titre

</label>

<input type="text"
       name="title"
       class="form-control"
       required>

</div>

<div class="mb-3">

<label class="form-label">

Description

</label>

<textarea name="description"
          class="form-control"
          required></textarea>

</div>

<div class="mb-3">

<label class="form-label">

Date

</label>

<input type="date"
       name="date"
       class="form-control"
       required>

</div>

<div class="mb-3">

<label class="form-label">

Lieu

</label>

<input type="text"
       name="place"
       class="form-control"
       required>

</div>

<button type="submit"
        name="add_contest"
        class="btn btn-primary">

Ajouter

</button>

</form>

</div>

</div>

<?php include("../includes/footer.php"); ?>