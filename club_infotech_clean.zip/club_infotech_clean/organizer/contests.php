<?php

include("../includes/db.php");
include("../includes/header.php");
include("../includes/navbar.php");

if(!isset($_SESSION['user'])){

    header("Location: ../login.php");

    exit();

}

$sql = "SELECT * FROM contests";

$result = mysqli_query($conn, $sql);

?>

<div class="container mt-5">

<h1 class="mb-4">

Liste des Concours

</h1>

<div class="card shadow p-4">

<table class="table table-bordered table-hover">

<thead class="table-dark">

<tr>

<th>ID</th>

<th>Titre</th>

<th>Description</th>

<th>Date</th>

<th>Lieu</th>

<th>Actions</th>

</tr>

</thead>

<tbody>

<?php while($row = mysqli_fetch_assoc($result)){ ?>

<tr>

<td>

<?php echo $row['id']; ?>

</td>

<td>

<?php echo $row['titre']; ?>

</td>

<td>

<?php echo $row['description']; ?>

</td>

<td>

<?php echo $row['date_concours']; ?>

</td>

<td>

<?php echo $row['lieu']; ?>

</td>

<td>
    <a href="edit_contest.php?id=<?php echo $row['id']; ?>"
   class="btn btn-warning btn-sm">

Modifier

</a>

<a href="delete_contest.php?id=<?php echo $row['id']; ?>"
   class="btn btn-danger btn-sm">

Supprimer

</a>

</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</div>

<?php include("../includes/footer.php"); ?>