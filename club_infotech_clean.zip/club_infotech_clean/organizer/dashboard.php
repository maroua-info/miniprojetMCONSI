<?php

include("../includes/header.php");

include("../includes/navbar.php");

if(!isset($_SESSION['user'])
   || $_SESSION['role'] != "organisateur"){

    header("Location: ../login.php");

    exit();

}

?>

<h1 class="mb-4">

Dashboard Organisateur

</h1>

<div class="alert alert-success">

Bienvenue :
<?php echo $_SESSION['user']; ?>

</div>

<div class="row mt-4">

<div class="col-md-4">

<div class="card shadow p-4 text-center">

<h2 class="text-primary">

12

</h2>

<p>Concours</p>

</div>

</div>

<div class="col-md-4">

<div class="card shadow p-4 text-center">

<h2 class="text-success">

45

</h2>

<p>Participants</p>

</div>

</div>

<div class="col-md-4">

<div class="card shadow p-4 text-center">

<h2 class="text-danger">

6

</h2>

<p>Résultats</p>

</div>

</div>

</div>

<div class="card shadow p-4 mt-5">

<h3 class="mb-4">

Actions Rapides

</h3>

<div class="d-grid gap-2">

<a href="add_contest.php"
   class="btn btn-primary">

Ajouter Concours

</a>

<a href="contests.php"
   class="btn btn-success">

Voir Concours

</a>

<a href="scores.php"
   class="btn btn-dark">

Calculer Scores

</a>

</div>

</div>

<?php include("../includes/footer.php"); ?>