<?php

include("../includes/db.php");

if(isset($_GET['id'])){

    $id = $_GET['id'];

    $sql = "DELETE FROM contests
            WHERE id = $id";

    mysqli_query($conn, $sql);

}

header("Location: contests.php");

exit();

?>