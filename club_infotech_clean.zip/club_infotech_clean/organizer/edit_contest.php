<?php

include("../includes/db.php");
include("../includes/header.php");
include("../includes/navbar.php");

if(!isset($_GET['id'])){

    header("Location: contests.php");

    exit();

}

$id = $_GET['id'];

$sql = "SELECT * FROM contests
        WHERE id = $id";

$result = mysqli_query($conn, $sql);

$contest = mysqli_fetch_assoc($result);

$message = "";

if(isset($_POST['update_contest'])){

    $title = $_POST['title'];
    $description = $_POST['description'];
    $date = $_POST['date'];
    $place = $_POST['place'];

    $update = "UPDATE contests
               SET
               titre='$title',
               description='$description',
               date_concours='$date',
               lieu='$place'
               WHERE id=$id";

    if(mysqli_query($conn, $update)){

        $message = "Concours modifié avec succès";

        header("Location: contests.php");

        exit();

    }

}

?>

<div class="container mt-5">

<h1 class="mb-4">

Modifier Concours

</h1>

<?php if($message != ""){ ?>

<div class="alert alert-success">

<?php echo $message; ?>

</div>

<?php } ?>

<div class="card shadow p-4">

<form method="POST">

<div class="mb-3">

<label>Titre</label>

<input type="text"
       name="title"
       class="form-control"
       value="<?php echo $contest['titre']; ?>"
       required>

</div>

<div class="mb-3">

<label>Description</label>

<textarea name="description"
          class="form-control"
          required><?php echo $contest['description']; ?></textarea>

</div>

<div class="mb-3">

<label>Date</label>

<input type="date"
       name="date"
       class="form-control"
       value="<?php echo $contest['date_concours']; ?>"
       required>

</div>

<div class="mb-3">

<label>Lieu</label>

<input type="text"
       name="place"
       class="form-control"
       value="<?php echo $contest['lieu']; ?>"
       required>

</div>

<button type="submit"
        name="update_contest"
        class="btn btn-primary">

Modifier

</button>

</form>

</div>

</div>

<?php include("../includes/footer.php"); ?>