<?php

include("../includes/db.php");
include("../includes/header.php");
include("../includes/navbar.php");

if(!isset($_SESSION['user'])){

    header("Location: ../login.php");

    exit();

}

$message = "";

if(isset($_POST['save_score'])){

    $participant = $_POST['participant'];

    $contest = $_POST['contest'];

    $complexity =
    $_POST['complexity'];

    $execution_time =
    $_POST['execution_time'];

    $contest_query =
    mysqli_query(
    $conn,
    "SELECT * FROM contests
     WHERE titre='$contest'"
    );

    $contest_data =
    mysqli_fetch_assoc(
    $contest_query
    );

    $coefficient =
    $contest_data['coefficient'];

    $score =
    $complexity
    *
    $execution_time
    *
    $coefficient;

    $sql =
    "INSERT INTO scores
    (participant,
    contest,
    complexity,
    execution_time,
    score)

    VALUES(

    '$participant',
    '$contest',
    '$complexity',
    '$execution_time',
    '$score'
    )";

    if(mysqli_query($conn, $sql)){

        $message =
        "Score ajouté avec succès";

    }

}

$result = mysqli_query(
$conn,
"SELECT * FROM scores"
);

?>

<div class="container mt-5">

<h1 class="mb-4">

Gestion Scores

</h1>

<?php if($message != ""){ ?>

<div class="alert alert-success">

<?php echo $message; ?>

</div>

<?php } ?>

<div class="card shadow p-4 mb-5">

<form method="POST">

<div class="mb-3">

<label>

Participant

</label>

<input type="text"
       name="participant"
       class="form-control"
       required>

</div>

<div class="mb-3">

<label>

Contest

</label>

<select name="contest"
        class="form-control"
        required>

<option value="">

Choisir un concours

</option>

<?php

$contests =
mysqli_query(
$conn,
"SELECT * FROM contests"
);

while(
$contest_row =
mysqli_fetch_assoc($contests)
){

?>

<option value="<?php
echo $contest_row['titre'];
?>">

<?php
echo $contest_row['titre'];
?>

</option>

<?php } ?>

</select>

</div>

<div class="mb-3">

<label>

Complexité

</label>

<input type="number"
       name="complexity"
       class="form-control"
       required>

</div>

<div class="mb-3">

<label>

Temps d'exécution

</label>

<input type="number"
       name="execution_time"
       class="form-control"
       required>

</div>

<button type="submit"
        name="save_score"
        class="btn btn-primary">

Ajouter Score

</button>

</form>

</div>

<div class="card shadow p-4">

<table class="table table-bordered
              table-hover">

<thead class="table-dark">

<tr>

<th>ID</th>

<th>Participant</th>

<th>Contest</th>

<th>Complexité</th>

<th>Temps</th>

<th>Score</th>

</tr>

</thead>

<tbody>

<?php while(
$row = mysqli_fetch_assoc($result)
){ ?>

<tr>

<td>

<?php echo $row['id']; ?>

</td>

<td>

<?php echo $row['participant']; ?>

</td>

<td>

<?php echo $row['contest']; ?>

</td>

<td>

<?php echo $row['complexity']; ?>

</td>

<td>

<?php echo $row['execution_time']; ?>

</td>

<td>

<?php echo $row['score']; ?>

</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</div>

<?php include("../includes/footer.php"); ?>