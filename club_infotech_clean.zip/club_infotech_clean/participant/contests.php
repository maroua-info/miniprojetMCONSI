<?php

include("../includes/header.php");
include("../includes/navbar.php");
include("../includes/db.php");

if(
!isset($_SESSION['user'])
|| $_SESSION['role'] != "participant"
){

    header("Location: ../login.php");

    exit();

}

$sql =
"SELECT * FROM contests";

$result =
mysqli_query($conn,$sql);

?>

<div class="container mt-5">

<h1 class="mb-4">

Liste Des Concours

</h1>

<div class="row">

<?php

while(
$contest =
mysqli_fetch_assoc($result)
){

?>

<div class="col-md-4 mb-4">

<div class="card shadow h-100">

<div class="card-body">

<h3 class="card-title">

<?php
echo $contest['titre'];
?>

</h3>

<p class="card-text">

<?php
echo $contest['description'];
?>

</p>

<p>

<b>Date :</b>

<?php
echo $contest['date_concours'];
?>

</p>

<p>

<b>Lieu :</b>

<?php
echo $contest['lieu'];
?>

</p>

<a href="participate.php?id=<?php echo $contest['id']; ?>"
   class="btn btn-primary">

Participer

</a>

</div>

</div>

</div>

<?php } ?>

</div>

</div>

<?php include("../includes/footer.php"); ?>