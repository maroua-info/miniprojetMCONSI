<?php

include("../includes/header.php");
include("../includes/navbar.php");
include("../includes/db.php");

if(
!isset($_SESSION['user'])
|| $_SESSION['role'] != "participant"
){

    header("Location: ../login.php");
    exit();

}

$username = $_SESSION['user'];

$user_query =
mysqli_query(
$conn,
"SELECT * FROM users
 WHERE username='$username'"
);

$user =
mysqli_fetch_assoc($user_query);

$user_id = $user['id'];

$sql =
"SELECT contests.*
 FROM registrations
 JOIN contests
 ON registrations.contest_id = contests.id
 WHERE registrations.user_id = '$user_id'";

$result =
mysqli_query($conn,$sql);

?>

<div class="container mt-5">

<h1 class="mb-4">

Mes Concours

</h1>

<div class="row">

<?php while($contest = mysqli_fetch_assoc($result)){ ?>

<div class="col-md-4 mb-4">

<div class="card shadow p-3">

<h3>

<?php echo $contest['titre']; ?>

</h3>

<p>

<?php echo $contest['description']; ?>

</p>

<p>

<b>Date :</b>

<?php echo $contest['date_concours']; ?>

</p>

<p>

<b>Lieu :</b>

<?php echo $contest['lieu']; ?>

</p>

</div>

</div>

<?php } ?>

</div>

</div>

<?php include("../includes/footer.php"); ?>