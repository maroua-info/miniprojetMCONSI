<?php

include("../includes/db.php");

session_start();

if(
!isset($_SESSION['user'])
){

    header("Location: ../login.php");

    exit();

}

$user =
$_SESSION['user'];

$get_user =
mysqli_query(
$conn,
"SELECT * FROM users
 WHERE username='$user'"
);

$user_data =
mysqli_fetch_assoc($get_user);

$user_id =
$user_data['id'];

$contest_id =
$_GET['id'];

$check =
mysqli_query(
$conn,
"SELECT * FROM registrations
 WHERE user_id='$user_id'
 AND contest_id='$contest_id'"
);

if(
mysqli_num_rows($check) == 0
){

    mysqli_query(
    $conn,
    "INSERT INTO registrations
    (user_id,contest_id)

    VALUES(
    '$user_id',
    '$contest_id'
    )"
    );

}

header(
"Location: contests.php"
);

exit();

?>