<?php

include("../includes/db.php");
include("../includes/header.php");
include("../includes/navbar.php");

$result =
mysqli_query(
$conn,
"SELECT * FROM scores
ORDER BY score DESC"
);

?>

<div class="container mt-5">

<h1 class="mb-4">

Classement Général

</h1>

<div class="card shadow p-4">

<table class="table table-bordered table-hover">

<thead class="table-dark">

<tr>

<th>Rang</th>

<th>Participant</th>

<th>Contest</th>

<th>Score</th>

<th>Status</th>

</tr>

</thead>

<tbody>

<?php

$rank = 1;

while($row = mysqli_fetch_assoc($result)){

?>

<tr>

<td>

<?php echo $rank; ?>

</td>

<td>

<?php echo $row['participant']; ?>

</td>

<td>

<?php echo $row['contest']; ?>

</td>

<td>

<?php echo $row['score']; ?>

</td>

<td>

<?php

if($rank == 1){

    echo '
    <span class="badge bg-warning text-dark">
    🏆 Winner
    </span>
    ';

}

else{

    echo '
    <span class="badge bg-secondary">
    Participant
    </span>
    ';

}

?>

</td>

</tr>

<?php

$rank++;

}

?>

</tbody>

</table>

</div>

</div>

<?php include("../includes/footer.php"); ?>