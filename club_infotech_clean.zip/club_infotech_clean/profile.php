<?php

include("includes/header.php");
include("includes/navbar.php");
include("includes/db.php");

if(!isset($_SESSION['user'])){

    header("Location: login.php");

    exit();

}

$user = $_SESSION['user'];

$participations_query =
mysqli_query(
$conn,
"SELECT COUNT(*) AS total
 FROM scores
 WHERE participant='$user'"
);

$participations =
mysqli_fetch_assoc(
$participations_query
);

$score_query =
mysqli_query(
$conn,
"SELECT MAX(score) AS best_score
 FROM scores
 WHERE participant='$user'"
);

$best_score =
mysqli_fetch_assoc(
$score_query
);

$wins_query =
mysqli_query(
$conn,
"SELECT COUNT(*) AS total_wins
 FROM scores
 WHERE participant='$user'
 AND score >= 90"
);

$wins =
mysqli_fetch_assoc(
$wins_query
);

?>

<div class="container mt-5">

<div class="row justify-content-center">

<div class="col-md-10">

<div class="card shadow-lg p-5">

<div class="text-center">

<img src="https://cdn-icons-png.flaticon.com/512/3135/3135715.png"
     width="120"
     class="mb-3">

<h2>

<?php echo $_SESSION['user']; ?>

</h2>

<span class="badge bg-primary">

<?php echo $_SESSION['role']; ?>

</span>

</div>

<hr class="my-4">

<?php if($_SESSION['role'] == "admin"){ ?>

<div class="row text-center">

<div class="col-md-4">

<div class="card p-4 shadow-sm border-0">

<h2 class="text-primary">

<?php

$users =
mysqli_query(
$conn,
"SELECT COUNT(*) AS total
 FROM users"
);

$data =
mysqli_fetch_assoc($users);

echo $data['total'];

?>

</h2>

<p>Membres</p>

</div>

</div>

<div class="col-md-4">

<div class="card p-4 shadow-sm border-0">

<h2 class="text-success">

<?php

$contests =
mysqli_query(
$conn,
"SELECT COUNT(*) AS total
 FROM contests"
);

$data =
mysqli_fetch_assoc($contests);

echo $data['total'];

?>

</h2>

<p>Concours</p>

</div>

</div>

<div class="col-md-4">

<div class="card p-4 shadow-sm border-0">

<h2 class="text-danger">

<?php

$scores =
mysqli_query(
$conn,
"SELECT COUNT(*) AS total
 FROM scores"
);

$data =
mysqli_fetch_assoc($scores);

echo $data['total'];

?>

</h2>

<p>Scores</p>

</div>

</div>

</div>

<?php } else { ?>

<div class="row text-center">

<div class="col-md-4">

<div class="card p-4 shadow-sm border-0">

<h2 class="text-primary">

<?php
echo $participations['total'];
?>

</h2>

<p>Participations</p>

</div>

</div>

<div class="col-md-4">

<div class="card p-4 shadow-sm border-0">

<h2 class="text-success">

<?php
echo $wins['total_wins'];
?>

</h2>

<p>Victoires</p>

</div>

</div>

<div class="col-md-4">

<div class="card p-4 shadow-sm border-0">

<h2 class="text-danger">

<?php
echo $best_score['best_score'];
?>

</h2>

<p>Meilleur Score</p>

</div>

</div>

</div>

<?php } ?>

<div class="mt-5">

<h4 class="mb-3">

Progression

</h4>

<div class="progress mb-4">

<div class="progress-bar bg-success"
     style="width: 80%">

80%

</div>

</div>

<h4 class="mb-3">

Achievements

</h4>

<span class="badge bg-warning text-dark p-2">

🏆 Winner

</span>

<span class="badge bg-info p-2">

💻 Web Expert

</span>

<span class="badge bg-success p-2">

🚀 Active Member

</span>

</div>

</div>

</div>

</div>

</div>

<?php include("includes/footer.php"); ?>