<?php

include("includes/header.php");
include("includes/navbar.php");
include("includes/db.php");

if(isset($_POST['register'])){

    $username = $_POST['username'];

    $email = $_POST['email'];

    $password = $_POST['password'];

    $hashed_password =
    password_hash(
    $password,
    PASSWORD_DEFAULT
    );

    $role = $_POST['role'];

    $sql = "INSERT INTO users
    (username,email,password,role)

    VALUES(
    '$username',
    '$email',
    '$hashed_password',
    '$role'
    )";

    mysqli_query($conn,$sql);

    echo '

    <div class="alert alert-success">

    Compte créé avec succès

    </div>

    ';

}

?>

<div class="card shadow p-5">

<h2 class="mb-4">

Créer un compte

</h2>

<form method="POST">

<div class="mb-3">

<label>

Nom utilisateur

</label>

<input type="text"
       name="username"
       class="form-control"
       required>

</div>

<div class="mb-3">

<label>

Email

</label>

<input type="email"
       name="email"
       class="form-control"
       required>

</div>

<div class="mb-3">

<label>

Mot de passe

</label>

<input type="password"
       name="password"
       class="form-control"
       required>

</div>

<div class="mb-3">

<label>

Role

</label>

<select name="role"
        class="form-control">

<option value="organisateur">

Organisateur

</option>

<option value="participant">

Participant

</option>

</select>

</div>

<button type="submit"
        name="register"
        class="btn btn-success">

Register

</button>

</form>

</div>

<?php include("includes/footer.php"); ?>