<?php

include("includes/db.php");
include("includes/header.php");
include("includes/navbar.php");

$sql = "SELECT * FROM scores
        ORDER BY score DESC";

$result = mysqli_query($conn, $sql);

?>

<div class="container mt-5">

<h1 class="mb-4 text-center">

Classement Général

</h1>

<div class="card shadow p-4">

<table class="table table-bordered
              table-hover">

<thead class="table-dark">

<tr>

<th>Rang</th>

<th>Participant</th>

<th>Contest</th>

<th>Score</th>

</tr>

</thead>

<tbody>

<?php

$rank = 1;

while($row = mysqli_fetch_assoc($result)){

?>

<tr>

<td>

<?php echo $rank; ?>

</td>

<td>

<?php echo $row['participant']; ?>

</td>

<td>

<?php echo $row['contest']; ?>

</td>

<td>

<?php

if($row['score'] >= 90){

    echo "<span class='badge bg-success'>
          ".$row['score']."
          </span>";

}

else if($row['score'] >= 70){

    echo "<span class='badge bg-warning text-dark'>
          ".$row['score']."
          </span>";

}

else{

    echo "<span class='badge bg-danger'>
          ".$row['score']."
          </span>";

}

?>

</td>

</tr>

<?php

$rank++;

}

?>

</tbody>

</table>

</div>

</div>

<?php include("includes/footer.php"); ?>